package com.dicoding.thegreatasean

object CountryData {
        private val countryNames = arrayOf("Brunei Darussalam",
                "Filipina",
                "Indonesia",
                "Kamboja",
                "Laos",
                "Malaysia",
                "Myanmar",
                "Singapura",
                "Thailand",
                "Vietnam")

    private val countryDetails = arrayOf("Negara yang dipimpin oleh Sultan ini merayakan hari kemerdekaannya setiap 23 Februari. Beribu kota di Bandar Seri Begawan, Brunei menggunakan Bahasa Melayu, Inggris, dan Mandarin sebagai bahasa resminya. " +
            "Negara ini berpenduduk 423.196 jiwa dengan mata uang Dollar Brunei. Sementara jumlah PDB per kapitanya mencapai US\$ 27.561 pada 2017 dan memiliki luas wilayah 5.765 km persegi.",
            "Filipina memiliki kepala negara dan kepala pemerintahan yang sama yakni Presiden. Negara yang beribu kota di Manila ini merayakan hari kemerdekaannya setiap 12 Juni.\n" +
            "Bahasa resmi yang digunakan adalah Tagalog dan Inggris serta menggunakan Kyat sebagai mata uang. Total PDB Filipina mencapai US\$ 348,6 miliar pada 2017. Filipina memiliki 103,3 juta jiwa penduduk dengan luas wilayah mencapai 343.448 km persegi.",
            "Indonesia memiliki kepala negara dan kepala pemerintahan yang sama yakni Presiden. Negara yang beribu kota di Jakarta ini merayakan hari kemerdekaannya setiap 17 Agustus.\n" + "Bahasa resmi yang digunakan adalah Bahasa Indonesia dengan Rupiah sebagai mata uangnya. Indonesia merupakan negara terbesar di ASEAN dengan luas wilayah 1,9 juta meter persegi dan 261,1 juta penduduk. Total PDB Indonesia mencapai US\$ 1.015 pada 2017.",
            "Kepala negara Kamboja adalah Raja sementara kepala pemerintahannya yakni Perdana Menteri.  Ibu kota negara dengan luas wilayah 181.035 km persegi ini adalah Phnom Penh.\n" + "Negara berpenduduk 15,76 juta jiwa ini merayakan hari kemerdekaan pada 9 November. Selain itu, negara ini memiliki PDB sebanyak US\$ 20,9 miliar pada 2017 dan menggunakan Riel (KHR) sebagai mata uang resmi.",
            "Laos merupakan satu-satunya negara di ASEAN yang tidak memiliki laut dengan luas wilayah 237.955 km persegi. Kepala negara di Laos adalah Presiden sementara kepala pemerintahan adalah Perdana Menteri.\n" + "Negara yang beribu kota di Vientiane ini merayakan hari kemerdekaannya setiap 2 Desember. Bahasa resmi negara berpenduduk 6,76 juta jiwa tersebut adalah Lao, Perancis, dan Inggris. Sementara GPD Laos mencapai 14,8 miliar dollar AS pada 2017.",
            "Malaysia memiliki kepala negara seorang Raja dan Perdana Menteri sebagai kepala pemerintahan. Negara yang beribu kota di Kuala Lumpur ini merayakan hari kemerdekaannya setiap 31 Agustus.\n" + "Bahasa resmi Malaysia adalah Melayu, Inggris, China, dan Tamil dengan mata uang Ringgit Malaysia. Negara berpenduduk 31,19 juta jiwa ini memiliki luas wilayah 329.847 km persegi dan PDB US\$ 336,3 miliar pada 2017.",
            "Myanmar memiliki kepala negara dan kepala pemerintahan yang sama yakni Presiden. Negara yang beribu kota di Nay Pyi Taw ini merayakan hari kemerdekaannya setiap 4 Januari.\n" + "Bahasa resmi yang digunakan adalah Burma dan menggunakan Kyat sebagai mata uang. Negara berpenduduk 52,89 juta jiwa ini memiliki luas wilayah 676.578 km persegi. Total GDP Myanmar mencapai US\$ 75,7 miliar pada 2017.",
            "Singapura memiliki jumlah penduduk 5,61 juta jiwa dan luas wilayah 721,5 km persegi. Kepala negara Singapura adalah Presiden sementara kepala pemerintahannya adalah Perdana Menteri.\n" + "Ibu kota negara ini yakni Singapura serta menggunakan Bahasa Inggris, China Mandarin, Melayu, dan Tamil sebagai bahasa resmi. Negara yang merayakan hari kemerdekaan setiap 9 Agustus ini memiliki PDB sebanyak US\$ 311,3 miliar.",
            "Thailand memiliki kepala negara seorang Raja dan Perdana Menteri sebagai kepala pemerintahan. Negara yang beribu kota di Bangkok ini merayakan hari kemerdekaannya setiap 5 Desember.\n" + "Bahasa resmi negara yang menggunakan mata uang Baht ini adalah Thai. Negara berpenduduk 68,86 juta jiwa ini memiliki luas wilayah 513.120 km persegi dan PDB US\$ 403,6 miliar pada 2017.",
            "Vietnam memiliki kepala negara seorang Presiden dan Perdana Menteri sebagai kepala pemerintahan. Negara yang beribu kota di Ho Chi Minh ini merayakan hari kemerdekaannya setiap 5 September.\n" + "Bahasa resmi negara yang menggunakan mata uang Dong ini adalah Vietnam. Negara berpenduduk 92,7 juta jiwa ini memiliki luas wilayah 331.230,8 km persegi dan PDB US\$ 215,9 miliar pada 2017.")

    private val countryFlags = intArrayOf(R.drawable.brunei_flag,
            R.drawable.filipina_flag,
            R.drawable.indonesia_flag,
            R.drawable.kamboja_flag,
            R.drawable.laos_flag,
            R.drawable.malaysia_flag,
            R.drawable.myanmar_flag,
            R.drawable.singapura_flag,
            R.drawable.thailand_flag,
            R.drawable.vietnam_flag)

    val listData: ArrayList<Country>
        get() {
            val list = arrayListOf<Country>()
            for (position in countryNames.indices) {
                val country = Country()
                country.name = countryNames[position]
                country.detail = countryDetails[position]
                country.flag = countryFlags[position]
                list.add(country)
            }
            return list
    }
}