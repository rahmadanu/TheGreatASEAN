package com.dicoding.thegreatasean

data class Country (
    var name: String = "",
    var detail: String = "",
    var flag: Int = 0
)
{
}